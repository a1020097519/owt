package com.xu.drools.bean;

public class Hope {

    public Hope() {

    }

}
