package com.xu.drools.web;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 使用drools来解决复杂问题
 */
@RequestMapping(value = "/rules")
@RestController
public class ComplexProblem {


}
